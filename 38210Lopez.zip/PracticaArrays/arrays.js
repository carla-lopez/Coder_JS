
let elementos ={
    kettlebell: 300,
    rack: 1500,
    almohadilla: 500,
};

let sum=0;
for(let suma in elementos){
    sum += elementos[suma];
}

alert(sum);

const barras = [
    {
        id: 1,
        nombre: 'barra hueca',
        peso: 3
    },
    {
        id:2,
        nombre: 'barra hueca 2',
        peso: 5

    },
    {
        id:3,
        nombre: 'Barra standar',
        peso: 8
    },
    {
        id:4,
        nombre: 'Barra standar',
        peso:10
    },
    {
        id:5,
        nombre: 'Barra olimpica',
        peso: 15

    },
    {
        id:6,
        nombre:'Barra olimpica',
        peso: 20
    },
    {
        id:7,
        nombre: 'Barra EZ',
        peso: 14
    },
    {
        id:8,
        nombre: 'Barra Romana',
        peso: 15
    }
];

const buscado= barras.find(barra => barra.id ===5);
console.log(buscado);

const olimpica = barras.filter (barra => barra.peso > 14);
console.log(olimpica);

const existe = barras.some(barra => barra.nombre === "Barra EZ");
console.log(existe);

const listNombres= barras.map(barra => barra.nombre);
console.log(listNombres);


const lista= ['Kettlebell','Rack','Almohadilla'];
let cantidad = 8;


do{
    let entrada= prompt("Ingresar producto");
    lista.push(entrada.toUpperCase());
    console.log(lista.length);
}while(lista.length != cantidad)
    
    const ListaNueva= lista.concat(["Mancuernas","Soga"]);
    alert(ListaNueva.join("\n"));




